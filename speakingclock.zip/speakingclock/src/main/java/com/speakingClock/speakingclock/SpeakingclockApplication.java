package com.speakingClock.speakingclock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpeakingclockApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpeakingclockApplication.class, args);
	}

}
